# Nauren 0.106.0 — Escritos: notas, cartas, pergaminhos, livros e diários

Escritos são Equipamentos com a categoria **Escrito (nota, carta, livro)**. O texto fica guardado no próprio item, escrito com o mesmo editor dos Jornais do Foundry. O jogador pega o escrito no baú, ele vai para o inventário, e o jogador clica em **Ler**.

## Onde estão os exemplos
Compêndio **Nauren - Equipamentos**:
- **Bilhete Amassado** — nota em papel envelhecido, com letra de caligrafia.
- **Carta Lacrada da Condessa** — carta com lacre de cera. A 2ª página tem um trecho **secreto** que só o Mestre vê.
- **Pergaminho: Bola de Fogo** — pergaminho **mágico**: tem a Ação "Ler em voz alta", que aparece no rodapé do leitor e na linha do inventário. O pergaminho some ao usar.
- **Tomo das Marés Coloridas** — livro com capa, páginas lado a lado e uma página de imagem.
- **Diário de Viagem** — diário em branco em que **o dono escreve**: o jogador anota o que quiser.

## Criar um escrito
1. Crie um Equipamento (ou arraste um exemplo) e, na aba **Geral**, mude a categoria para **Escrito (nota, carta, livro)**.
2. A ficha ganha a aba **Escrito**, que mostra a miniatura, quantas páginas tem e os botões **Ler**, **Escrever as páginas** e **Mostrar aos jogadores**.
3. Na mesma aba ficam as opções:
   - **Formato:** Nota, Carta, Pergaminho, Livro ou Diário. Cada formato já sugere um papel e uma letra.
   - **Papel:** Envelhecido, Pergaminho, Creme, Branco, Noturno ou Arcano.
   - **Letra:** Caligrafia, Livro, Clássica, Antiga, Letreiro ou Simples. Dá para escolher também a cor da tinta e o tamanho da letra.
   - **Capa** (livro e diário): título, linha de baixo, cor do couro e cor dos detalhes.
   - **Lacre** (carta): ligado ou desligado, cor da cera e uma letra no selo. Depois de rompido, dá para **lacrar de novo**.
   - **Quem pode escrever:** só o Mestre, ou o dono também.
   - **Ler no baú:** dá para ler no baú sem pegar.
   - **Some ao usar uma Ação:** para pergaminhos de magia.

## Escrever
**Escrever as páginas** abre a janela em modo de escrita:
- **À esquerda:** a lista de páginas, com subir, descer e apagar. **+ Texto** e **+ Imagem** criam páginas novas, e **Aparência** traz as mesmas opções da ficha.
- **À direita:** o título da página e o editor, já no papel e na letra escolhidos.
- O editor é o dos Jornais: títulos, listas, imagens, links @UUID, rolagens e o bloco **Segredo**, que só o Mestre vê.
- O texto é salvo sozinho ao trocar de página, ao clicar em **Ver como fica** ou ao fechar. **Ctrl+S** salva na hora.
- **Arraste um Jornal** (ou uma página dele) para a lista: as páginas de texto e de imagem são copiadas para o escrito.

## Ler
- **Inventário:** o botão **Ler** fica na linha do item. "Usar" só aparece se o escrito tiver Ação.
- **Baú:** quando o escrito está escolhido, aparece **Ler aqui**. Se a opção estiver desligada, só o Mestre vê o botão.
- **Navegação:** as setas e as teclas ← e → viram as páginas, e a lista no alto pula para qualquer página. **A−** e **A+** mudam o tamanho da letra só na sua tela.
- **Livro e diário:** abrem na capa; clique para abrir e veja as páginas lado a lado.
- **Carta lacrada:** abre no envelope; clique no lacre para rompê-lo.
- **Pergaminho:** aparece com as varetas; as Ações mágicas ficam no rodapé.
- **Mostrar aos jogadores:** o Mestre clica no 👁 e o escrito abre na tela de todos. Também fica um card no chat com o botão **Ler**.

## O que observar no Foundry
- O editor de verdade (ProseMirror) só existe no Foundry; o simulador usa uma caixa de texto simples. Confira:
  - se a barra de ferramentas do editor aparece;
  - se o texto salva ao trocar de página;
  - se o bloco Segredo some para o jogador.
- As fontes novas aparecem também na lista de fontes do editor de Jornais: Nauren Livro, Caligrafia, Clássica e Antiga.
- Dois escritos de mesmo nome não viram pilha no baú, porque cada um tem o seu texto.

Fontes incluídas (livres para redistribuir; licenças em `assets/fontes`): Lora (OFL), TeX Gyre Chorus e Pagella (GUST) e GFS Baskerville (OFL).
