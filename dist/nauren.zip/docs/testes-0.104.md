# Nauren 0.104.0 — roteiro de testes

Seis mudanças. Cada teste diz onde fica, o que fazer e o que deve acontecer.

## 1. Molduras prontas do Mestre
**Onde:** janela da borda do token (ficha → Borda do Token) → galeria → botão **Prontas do Mestre** (fica embaixo das categorias).
1. Como Mestre, escolha uma moldura, mude as cores e os efeitos e clique no quadro **Salvar a atual**. Dê um nome (ex.: "Chefe").
   → A pronta aparece na lista com a miniatura. Ela guarda só o visual: modelo, cores, efeitos e reações. A imagem do personagem não vai junto.
2. Abra a borda de outro personagem → Prontas do Mestre → clique em "Chefe".
   → O visual muda na prévia, a imagem do personagem continua a dele e a galeria fica aberta.
3. Selecione 2 ou 3 tokens de monstro no mapa e, com a pronta escolhida, clique em **Aplicar nos N tokens selecionados**.
   → Cada token ganha a moldura com a própria arte. A ficha do monstro no bestiário não muda, só os tokens.
4. Passe o mouse num quadro de pronta e clique no **×** para apagar.
   → Os tokens que já usavam essa moldura continuam com ela.

## 2. Moldura automática ao colocar no mapa
**Onde:** Configurações do jogo → **Configurações do Nauren** → Molduras dos tokens → Moldura automática.
1. Em "Inimigos (hostil)", escolha uma pronta e salve.
2. Arraste um monstro (token não vinculado, disposição hostil) para o mapa.
   → Ele já entra com a moldura escolhida.
3. Arraste um aliado ou um personagem de jogador.
   → Entra sem moldura automática. O aliado não tem pronta escolhida, e o personagem é vinculado: a opção "Só em tokens não vinculados" vem ligada.

## 3. Galeria: favoritas, recentes e arte do personagem
**Onde:** galeria da borda.
1. As miniaturas mostram a arte do personagem dentro de cada moldura.
2. Passe o mouse num quadro e clique na **estrela**. Abra **Favoritas**.
   → A moldura está lá. Clique na estrela de novo para tirar.
3. Salve uma borda e reabra a janela → **Recentes**.
   → A última que você salvou aparece primeiro.
Favoritas e recentes são de cada jogador.

## 4. Acabamento igual nos 40 modelos
**Onde:** galeria e mapa.
- Todas as molduras usam o mesmo contorno escuro na silhueta, tanto nas peças cheias quanto nas linhas. Os fios do Trigo, por exemplo, agora têm o mesmo contorno dos grãos.
- A sombra ficou curta e suave, então linhas finas juntas não viram uma faixa escura.
- Confira 3 ou 4 modelos de linha fina (Trigo, Aro Duplo, Déco Placas) no mapa, com zoom.

## 5. Configurações do Nauren (painel único)
**Onde:** Configurações do jogo → Configurar Configurações → Sistema → **Configurações do Nauren**.
1. Na lista do Foundry sobra só o botão do painel. As opções que antes ficavam soltas estão todas dentro dele.
2. Lateral com 10 assuntos: Interface, Chat e cards, Combate, Tokens e Vida, Carrossel do combate, Arte ao passar o mouse, Equipamento e itens, Criação de personagem, Animações e sons, Molduras dos tokens.
3. Mude 2 opções → as linhas ficam marcadas, um ponto aparece no assunto e o botão mostra **Salvar (2)**. Salve e confira que mudou.
4. **Procurar em todas**: digite "prioridade" → aparecem as opções de todos os assuntos que falam disso.
5. O ícone de voltar ao padrão aparece nas opções que estão diferentes do padrão.
6. "Equipamento e itens" tem o botão do editor de **Tiers dos itens**.
7. Entre como jogador e abra o painel → as opções do **Mundo** ficam travadas e as marcadas **Só nesta tela** ele pode mudar.

## 6. Janelas antigas no acabamento novo
**Onde:** Criador de Personagem, Criador de Monstros, Barras do token, Recursos do HUD, Bancada de Invenção e Obra Prima.
- Campos de texto, número e listas ficam chanfrados, como nas janelas novas. As caixas de marcar e os controles deslizantes ficam dourados.
- Os títulos da Bancada, da Obra Prima, das Barras e do Criador de Monstros estão em Signika. O Criador de Personagem mantém o estilo das fichas.
- A Bancada e a Obra Prima trocaram os cantos arredondados pelos chanfrados. A faixa colorida das categorias da Bancada continua.
- **Firefox com escala de 125%**: confira que nenhum canto some nas diagonais.

## 7. Divisão do arquivo principal (nada muda para o jogador)
O `nauren.mjs` foi dividido em 18 módulos novos: HUD de Combate, Barras, Carrossel, Bando, Inventor, Criador de Monstros, Movimento, Prioridades e outros. Ele caiu de 16.500 para cerca de 8.200 linhas. Nenhuma regra mudou.
- Teste rápido: abra o mundo, confira o console (F12) e veja se não aparece nenhum erro em vermelho do Nauren. Depois faça um combate curto com uma Ação, uma reação e o movimento.
