# Nauren 0.105.0 — Aparência (roteiro de testes)

Condições, Efeitos, Habilidades, Peculiaridades, armas e armaduras ganharam a aba **Aparência**. Com ela, o item muda como o personagem aparece no mapa enquanto valer: imagem, tamanho e borda, e o retrato da ficha se você quiser. Tem também gatilhos, prioridade e uma transição com animação e som.

A antiga "Transformação de Token" virou Aparência. As que você já tinha são convertidas sozinhas quando o Mestre abre o mundo.

## 1. Condição de Aparência (o caso mais simples)
**Onde:** crie uma Condição (ex.: "Profusão") → aba **Aparência**.
1. Em **Ícone desta Condição**, escolha **Só na ficha**.
2. Ligue **Aparência no mapa**. Em **Imagem nova**, escolha outra imagem e marque **Trocar também o retrato da ficha**. Em Tamanho, escolha 2×2. Em Borda, escolha **Uma pronta** e selecione uma.
3. Arraste a Condição para a ficha de um personagem que está no mapa.
   → O token troca de imagem, vira 2×2 e ganha a borda da pronta. O retrato da ficha troca também. Não aparece ícone no token nem no HUD de Combate.
4. Apague a Condição da ficha.
   → Volta tudo: imagem, tamanho, a borda de sempre e o retrato.

## 2. Montar a borda ali mesmo
1. Na aba Aparência, em Borda, escolha **Montar a minha** → **Montar a borda**.
   → Abre o editor de bordas com o título "Borda da aparência". O botão de salvar diz **Usar na aparência**.
2. Escolha um modelo, mude as cores e clique em **Usar na aparência**.
   → A borda fica guardada no item. A borda de sempre do personagem (a da ficha) **não muda**.
3. A **Prévia** no fim da aba mostra a imagem com a borda escolhida.

## 3. Vilão que muda de forma (gatilho)
1. Na ficha do vilão, crie um Efeito ligado → aba Aparência → ligue, ponha a imagem da segunda fase, 3×3 e uma borda.
2. Em **Quando vale** → **+ Gatilho** → **Vida abaixo de** 50%.
3. Coloque o vilão no mapa e tire Vida até ficar abaixo da metade.
   → Ele muda sozinho. Cure acima da metade → volta.
4. Tokens não vinculados (monstros): só aquele token muda. O modelo do bestiário fica como está.

## 4. Gatilhos disponíveis
Vida abaixo de X% · Vida em 0 · Tem a Condição (pelo nome, com N acúmulos ou mais) · Não tem a Condição · Recurso ≥ ou ≤ N (Vida, Mana, Estamina, Estresse, Dados de Destino, Escudo) · Em combate · Fora de combate · No seu turno.
Com vários gatilhos, precisa bater **todos**. Exemplo: "Tem a Condição Furioso" e "Estresse ≥ 1".

## 5. Duas ao mesmo tempo (prioridade)
Duas aparências valendo juntas: cada parte (imagem, tamanho, borda) vem da de **maior prioridade** que mexe naquela parte.
Exemplo: um Efeito de prioridade 5 com borda dourada e 2×2, e outro de prioridade 2 que tira a borda → vale a borda dourada e o 2×2. Desligando o de prioridade 5, vale o "sem borda", com o tamanho normal.

## 6. Transição
Em **Transição**, escolha uma animação (a lista sugere algumas do JB2A, mas pode digitar qualquer uma) e/ou um som, para quando a aparência entra e quando sai. A animação precisa do módulo **Sequencer**; sem ele, só o som toca.

## 7. Arma ou armadura
Uma arma com Aparência só vale **equipada**. Equipe → muda. Desequipe → volta.

## O que observar no Foundry
- Mover o token, mudar de cena e recarregar (F5) com uma aparência ativa: ela continua aplicada.
- Mudar a borda de sempre (janela da borda) com uma aparência ativa: a borda nova passa a ser a de sempre, e a aparência continua por cima enquanto valer.
- Com jogador e Mestre conectados, a mudança acontece uma vez só (quem aplica é o Mestre).
