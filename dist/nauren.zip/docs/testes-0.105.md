# Nauren 0.105.0 — Aparência (roteiro de testes)

Condições, Efeitos, Habilidades, Peculiaridades, armas e armaduras ganharam a aba **Aparência**. Com ela, o item muda como o personagem aparece no mapa enquanto valer: imagem, tamanho e borda, e o retrato da ficha se você quiser. Tem também gatilhos, prioridade e uma transição com animação e som.

A antiga "Transformação de Token" virou Aparência. As que você já tinha são convertidas sozinhas quando o Mestre abre o mundo.

## 1. Condição de Aparência (o caso mais simples)
**Onde:** crie uma Condição (ex.: "Profusão") → aba **Aparência**.
1. Em **Ícone desta Condição**, escolha **Só na ficha**.
2. Ligue **Aparência no mapa**. Em **Imagem nova**, escolha outra imagem e marque **Trocar também o retrato da ficha**. Em Tamanho, escolha 2×2. Em Borda, escolha **Uma pronta** e selecione uma.
3. Arraste a Condição para a ficha de um personagem que está no mapa.
   → O token troca de imagem, vira 2×2 e ganha a borda da pronta. O retrato da ficha troca também. Não aparece ícone no token nem no HUD de Combate.
4. Apague a Condição da ficha.
   → Volta tudo: imagem, tamanho, a borda de sempre e o retrato.

## 2. Montar a borda ali mesmo
1. Na aba Aparência, em Borda, escolha **Montar a minha** → **Montar a borda**.
   → Abre o editor de bordas com o título "Borda da aparência". O botão de salvar diz **Usar na aparência**.
2. Escolha um modelo, mude as cores e clique em **Usar na aparência**.
   → A borda fica guardada no item. A borda de sempre do personagem (a da ficha) **não muda**.
3. A **Prévia** no fim da aba mostra a imagem com a borda escolhida.

## 3. Vilão que muda de forma (gatilho)
1. Na ficha do vilão, crie um Efeito ligado → aba Aparência → ligue, ponha a imagem da segunda fase, 3×3 e uma borda.
2. Em **Quando vale** → **+ Gatilho** → **Vida abaixo de** 50%.
3. Coloque o vilão no mapa e tire Vida até ficar abaixo da metade.
   → Ele muda sozinho. Cure acima da metade → volta.
4. Tokens não vinculados (monstros): só aquele token muda. O modelo do bestiário fica como está.

## 4. Gatilhos disponíveis
Vida abaixo de X% · Vida em 0 · Tem a Condição (pelo nome, com N acúmulos ou mais) · Não tem a Condição · Recurso ≥ ou ≤ N (Vida, Mana, Estamina, Estresse, Dados de Destino, Escudo) · Em combate · Fora de combate · No seu turno.
Com vários gatilhos, precisa bater **todos**. Exemplo: "Tem a Condição Furioso" e "Estresse ≥ 1".

## 5. Duas ao mesmo tempo (prioridade)
Duas aparências valendo juntas: cada parte (imagem, tamanho, borda) vem da de **maior prioridade** que mexe naquela parte.
Exemplo: um Efeito de prioridade 5 com borda dourada e 2×2, e outro de prioridade 2 que tira a borda → vale a borda dourada e o 2×2. Desligando o de prioridade 5, vale o "sem borda", com o tamanho normal.

## 6. Transição
Em **Transição**, escolha uma animação (a lista sugere algumas do JB2A, mas pode digitar qualquer uma) e/ou um som, para quando a aparência entra e quando sai. A animação precisa do módulo **Sequencer**; sem ele, só o som toca.

## 7. Arma ou armadura
Uma arma com Aparência só vale **equipada**. Equipe → muda. Desequipe → volta.

## O que observar no Foundry
- Mover o token, mudar de cena e recarregar (F5) com uma aparência ativa: ela continua aplicada.
- Mudar a borda de sempre (janela da borda) com uma aparência ativa: a borda nova passa a ser a de sempre, e a aparência continua por cima enquanto valer.
- Com jogador e Mestre conectados, a mudança acontece uma vez só (quem aplica é o Mestre).

---

# 0.105.1 — Pincel na frente, detalhes invisíveis e painel de configurações

## A. Onde ficam as Configurações do Nauren
Na 0.105.0, o botão do painel sumia da lista do Foundry. Foi corrigido.
**Caminho:** Configurações (engrenagem na barra da direita) → **Configurar Configurações** → seção **Nauren RPG** → linha **Configurações do Nauren** → botão **Abrir as configurações**.
→ Abre o painel com 10 assuntos na lateral e uma busca no alto.

## B. Pincel na frente da moldura
1. Abra a borda de um personagem, escolha um modelo Nauren (ex.: Déco Placas) e vá na aba **Pincel**.
2. Ligue a **Guia** e escolha **Mostrar** no alto da prévia. Pinte por cima do aro, onde a cabeça ou a arma deveria sair.
   → O pintado aparece **por cima** do aro.
3. Desmarque **Na frente** → o pintado volta para trás do aro. Marque de novo.
4. Salve. No mapa, ligue **Girar** na aba Efeitos.
   → O aro gira e o pedaço pintado fica parado, por cima.
5. Com **Esconder**, pinte por cima de um pedaço que você mostrou → aquele pedaço some (da frente também).

## C. Detalhes invisíveis
1. Escolha um modelo com detalhes (ex.: Selo Real) → aba **Cores** → **Detalhes**.
2. Marque **Invisível** embaixo de Esmalte e/ou Gema.
   → Aquela parte fica transparente, e o seletor de cor trava. Desmarque para a cor voltar.

---

# 0.105.2 — Ajustes da Aparência, Regiões e cintilar

## A. Borda por baixo das Regiões
O Foundry abre um buraco no realce das Regiões no formato da arte do token. Agora a moldura Nauren abre esse buraco também.
1. Ponha um token com moldura Nauren dentro de uma Região com realce (as listras).
   → As listras ficam por baixo da moldura, como já ficavam por baixo da arte.

## B. Cintilar mais perto e com ajustes
Editor da borda → **Efeitos** → **Cintilar**. Há duas réguas novas: **Distância da moldura** e **Tamanho das estrelas**. O padrão agora fica um pouco mais perto e com estrelas menores.

## C. Aparência
1. **Rolagem:** mexa em qualquer opção lá embaixo da aba → a ficha não volta para o topo.
2. **Tamanho do token:** a lista vai até 16×16.
3. **Montar a minha com imagem nova:** preencha a **Imagem nova** e clique em **Montar a borda**.
   → O editor abre com a imagem nova e no tamanho da aparência. O pincel pinta sobre ela e fica guardado no item.
4. **Manter a atual com imagem nova:** a borda de sempre vale sem o pincel e o enquadre, porque eles eram da imagem antiga.
5. **Transição:**
   - Com Sequencer e JB2A ativos, a lista mostra todas as animações que eles têm.
   - Sem Sequencer ou sem módulo de animações, aparece um aviso.
   - Uma animação que não existe fica com a borda vermelha.
   - A animação acompanha o tamanho novo do token. Ajustes: **Tamanho** (em vezes o token), opacidade, velocidade, cor (matiz), repetir, atraso, por baixo do token, espelhar e volume do som.
   - **Testar** toca a transição no token do personagem.
6. **Troca suave** (ligada por padrão): a imagem antiga some aos poucos por cima da nova.
7. A bolinha do lado do nome da aba Aparência saiu.

## D. Carrossel
Com uma aparência valendo, o carrossel continua com o retrato de sempre. Ele só troca se a opção **Trocar também o retrato da ficha** estiver marcada, mesmo com o carrossel em "Imagem do token".

---

# 0.105.3 — Troca suave refeita, JB2A no tamanho final, detalhes invisíveis de verdade

## A. Troca suave
A 0.105.2 tirava uma "foto" do mapa, e ela saía deslocada. Agora o token (arte e moldura) esmaece, a aparência nova é montada enquanto ele está apagado, e depois ele volta aos poucos. Isso só acontece na tela de cada um; nada vai para o mundo.
1. Ligue e desligue uma Condição de Aparência com imagem nova e 3×3.
   → O token some suave, troca e volta suave, sem pedaço de mapa por cima.

## B. Animação do JB2A no tamanho final
A animação de entrada e de saída agora começa junto com a troca e já vem no tamanho que o token vai ter, no centro dele. Ela usa o molde do JB2A para a parte visível cobrir o token. **Tamanho** é em vezes o token.
1. Aparência de 1×1 para 3×3 com `jb2a.misty_step.01.blue`.
   → A fumaça cobre o 3×3 já no começo.

## C. Detalhes invisíveis com efeitos de cor
Em vários modelos existe metal por baixo do esmalte e da gema. Ao deixar o detalhe invisível, esse metal aparecia e pegava a cor do Ciclo e do Pulso. Agora o lugar do detalhe vira buraco em todas as camadas.
1. Coroa Solar → Esmalte **Invisível** → efeito **Ciclo de cores**.
   → Os medalhões ficam vazados (mostram o mapa) e não pegam a cor.
