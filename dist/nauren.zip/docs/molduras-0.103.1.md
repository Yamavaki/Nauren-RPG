# Molduras de token — 0.103.1 (correções do primeiro teste)

Roteiro rápido do que mudou. O roteiro completo da 0.103 continua em `planejamento/molduras-0.103.md`.

## Corrigido
1. **Imagem preta em vários modelos** (Aro Liso, Aro Duplo, Corda, Serrilha, Sol de Pétalas, Estrela Octogonal, Prisma, Leque, Flor-de-lis, Coroa Solar, Espinhos, Selo Real, Engrenagem): o desenho interno da silhueta saía com um atributo repetido e o navegador recusava a imagem. Teste: abra a galeria e clique em todos os modelos, um por um — a prévia mostra a arte e a moldura em todos.
2. **Borda some ao mover o token**: o clone que o Foundry cria ao arrastar tem o mesmo id do token, e ao soltar ele apagava a moldura do token de verdade. Agora cada token (e o clone) tem a sua. Teste: arraste o token várias vezes, solte, mova com o teclado — a moldura fica.
3. **Janela não alargava para os lados**: uma regra de outra janela limitava a 980 px. Teste: puxe o canto da janela para a direita; a prévia cresce junto.
4. **Esmalte/Gema sem efeito**: agora só aparecem os controles que o modelo usa (ex.: Selo Real e Louros têm gema; Déco Colchetes não tem nenhum dos dois, então "Detalhes" some).

## Galeria
- A galeria **fica aberta** ao escolher uma moldura (dá para ir clicando uma por uma e ver na prévia); a aba aberta e a rolagem ficam onde estavam. "Fechar a galeria" fecha.
- Categorias novas: **Essenciais** (Padrão do Foundry, Minha imagem e os aros simples), **Geométricas**, **Elegantes**, **Natureza**, **Arcanas**.
- O quadrinho do Padrão do Foundry mostra a borda do Foundry desenhada.
- Sem os textos de explicação embaixo da galeria.
- **Hextech** passou a se chamar **Prisma** (bordas já salvas com o nome antigo continuam funcionando).

## Desenhos
- **Dente de Serra** e **Triângulos Encaixados**: anel e triângulos viraram uma peça só (sem a linha entre eles); o círculo de fora do Dente de Serra continua separado.
- **Estrela Foliada**: faixa e folhas numa peça só, sem a linha circular cruzando as folhas.

## Efeitos
- **Girar**: o recorte da arte agora gira junto com a moldura (nas molduras que não são redondas por dentro, como Déco Coroa, Picos Cardeais, Estrela Entrelaçada). Os traços do pincel continuam presos na arte.
- **Só por fora da imagem** (Aura, Neon, Cintilar): o efeito fica atrás da arte e aparece só em volta.
- **Cintilar**: bem mais estrelas, maiores e mais fortes.

## Reações
Nova aba em cartões (Vida: Dano, Cura, Vida baixa, Caído · Combate: Seu turno, Cor do lado, Condições), com chave liga/desliga; a cor do piscar de dano e de cura fica no próprio cartão.

## Regiões por cima do token
As listras de Região (Regions) são desenhadas pelo Foundry na camada de interface, **por cima de todos os tokens** — da arte, da borda do Foundry e das molduras. Não dá para pôr a moldura por cima sem ela passar também por cima de telhados e do clima. Se atrapalhar, na configuração da Região troque a visibilidade para aparecer só com a ferramenta de Regiões aberta.
